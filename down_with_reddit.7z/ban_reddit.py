import discord
client = discord.Client()

@client.event
async def on_ready():
    print('Working.')

@client.event
async def on_message(message):
    print(message.author,':', message.content)
    if 'reddit.com' in message.content or 'redd.it' in message.content:
    	return
    elif 'reddit' in message.content:
    	await message.delete()
    	print('REDDIT DETECTED')

client.run('NzA5MTQxNjE0MjY5OTU2MTQ3.Xrhm1A.kHdGk28feUYTHBGkQpj8X7ZhWB0')
